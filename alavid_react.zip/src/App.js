import './App.css';
import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import CreateExercisePage from './pages/CreateExercise';
import EditExercisePage from './pages/EditExercise';
import {useState} from 'react';
import { Link } from 'react-router-dom';

function App() {
  const [exerciseToEdit, setExerciseToEdit] = useState();


  return (
    <div className="App">
      <h1>Exercise Logging Tool</h1>
      <p>Welcome to the exercise logging tool. This tool will help keep track of your exercises by allowing you to create an update different workouts</p>
      <Router>
      <nav>
        <Link to= "/">Home</Link>
      </nav>
      <nav>
        <Link to = "/Create-Exercise">Create Exercise</Link>
      </nav>
        <div className="App-header">
          <Route path="/" exact>
            <HomePage setExerciseToEdit = {setExerciseToEdit} />
          </Route>
          <Route path="/Create-Exercise">
            <CreateExercisePage />
          </Route>
          <Route path="/Edit-Exercise">
            <EditExercisePage exerciseToEdit ={exerciseToEdit}/>
          </Route>
          </div>
      </Router>
      <footer>© 2022 Davood Alavi</footer>
    </div>
  );
}

export default App;
