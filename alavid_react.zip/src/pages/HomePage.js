import React from 'react';
import { Link } from 'react-router-dom';
import ExerciseList from '../components/exerciseList';
import {useState,useEffect} from 'react';
import {useHistory} from "react-router-dom";
import '../App.css';


function HomePage({setExerciseToEdit}){

    const [exercises, setExercise] = useState([]);
    const history = useHistory();

    const onDelete = async _id =>{
        const response = await fetch(`/exercises/${_id}`,{method: 'DELETE'});
        if (response.status ===204){
            const newExercise = exercises.filter(e=> e._id !== _id);
            setExercise(newExercise);
        }else {
            console.error(`Failed to delete exercise with _id = ${_id}, status code = ${response.status}`);
        }
    };

    const onEdit = async exercise => {
        setExerciseToEdit(exercise);
        history.push("/Edit-Exercise");

    }

    const loadExercises = async () => {
        const response = await fetch ('/exercises/');
        const data = await response.json();
        setExercise(data);
    }

    useEffect(() => {
        loadExercises();
    }, []

    );

    return (
        <>
            <h2> List of Exercises</h2>
            <ExerciseList exercises={exercises} onDelete={onDelete} onEdit={onEdit} ></ExerciseList>
            <Link to ="/Create-Exercise">Create an exercise</Link>        
        </>
    );
}

export default HomePage;